from django.contrib import admin
from . models import Administrator


# Register your models here.

admin.site.register(Administrator)